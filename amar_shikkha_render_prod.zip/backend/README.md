Backend Notes:
- This backend uses Prisma + PostgreSQL. After setting DATABASE_URL in .env, run:
  npx prisma generate
  npx prisma migrate dev --name init
- Start server: npm run dev
- Create admin user via /api/auth/register with role ADMIN (or use Prisma Studio)
