# Amar Shikkha — Madrasa ERP (Production scaffold)
This scaffold is built to be deployed on Render with a managed PostgreSQL database.
It contains:
- backend/: Node.js + Express + Prisma (Postgres)
- frontend/: React (basic)
- prisma/: schema for database models

## Quick start (local, dev)
1. Backend:
   - cd backend
   - cp .env.example .env
   - edit .env and set DATABASE_URL (local Postgres)
   - npm install
   - npx prisma generate
   - npx prisma migrate dev --name init
   - npm run dev
2. Frontend:
   - cd frontend
   - npm install
   - npm start

## Deploy to Render (recommended)
1. Create a GitHub repo and push the contents of this project.
   ```bash
   git init
   git add .
   git commit -m "Initial Amar Shikkha prod scaffold"
   git branch -M main
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```
2. On Render:
   - Create a **Managed PostgreSQL** database (note the DATABASE_URL).
   - Create a **Web Service** for the backend:
     - Connect GitHub repo, select root `backend`.
     - Build Command: `npm ci && npx prisma generate && npx prisma migrate deploy`
     - Start Command: `npm start`
     - Add environment variables: `DATABASE_URL`, `JWT_SECRET`, `FRONTEND_URL`, etc.
   - Create a **Static Site** for the frontend:
     - Root: `frontend`
     - Build Command: `npm ci && npm run build`
     - Publish Directory: `build`
   - OR serve the frontend from the backend (the backend already serves `frontend/build` if present).
3. After deploy, run migrations using Render shell or ensure `npx prisma migrate deploy` runs during build.

## Notes
- This scaffold includes authentication (JWT) and role-based middleware.
- The UI is intentionally minimal. I can build a full-featured frontend (student forms, fees UI, attendance sheet, results, PDF receipts, SMS notifications).
- For persistent file storage (student photos), integrate S3 or a similar storage provider and store the URL in DB.
- SMS/email integration must be added with provider API keys in Render environment settings.

## Next steps I can implement for you (pick any)
- Full React admin dashboard (students, teachers, fees, attendance, results, PDF export).
- Mobile app with Flutter/React Native.
- SMS (Twilio/BulkSMSBD) & PDF receipts integration.
- Automated backups and scheduled reports.
